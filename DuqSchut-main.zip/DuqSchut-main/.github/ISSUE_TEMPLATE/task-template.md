---
name: Task template
about: Task for a user story
title: ''
labels: ''
assignees: ''

---

**Detailed task description.**
If the task is not obvious from the issue title, provide more detail here.

**Initial estimate of time required to complete this task.**
Initial estimate, in hours, of the time required to complete this task. This value should not be changed.

**Actual time spent on the task (so far).**
Total number of hours spent on this task. This value should be updated at the end of each session working on the task.

**Current estimate of time remaining to complete this task.**
Estimate, in hours, of the work left to do to complete this task. This value should be updated at the end of each session working on the task.
