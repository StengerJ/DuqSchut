# User Acceptance Test for 25: As an administrator, I want to be able to enter templates [ ON A SEPARATE PAGE? AND RULES FOR WHAT IT SENT TO WHOM? ] for automated emails such as appointment confirmations, appointment reminders, and cancellation notices.

1. From the home page, click the login button under the DuqSchut logo.
2. Next to Email: enter lipeckya@duq.edu, and then any password next to Password:
3. Click the log in button, you will be directed to the Admin welcome page
4. Click the button "Email Templates", you will be directed to a page which displays email templates and allows you to edit them. 
5. You should see the information corresponding to the email template chosen in Template Type
6. Click on the Template Type drop down to select one of the tree template types you wish to edit or view (Confirmation, Cancellation, or Reminder)
7. Once the type is chosen, the information of that template will appear
8. Click on any field you wish to edit and make changes to (Name, Subject, Template Body)
9. Click the save button on the bottom of the page, your changes will now be saved to the database
10. Click the back buttom to return to the admin page
