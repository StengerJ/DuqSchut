# User Acceptance test for 50: As any user, I want a direct link to take me to the DuqSchut home page, and ideally this link will be accessible via a tile in the Duquesne portal

1. From the home page click the login button under the image.
2. Enter next to Multipass Username: bowmanj1@duq.edu and next to Name: Jessica Bowman.
3. Click the Login button. You will be directed to the student(tutee) home page where you should see an appointment for Jessica Bowman.
4. Go back to the Login page by typing /login of localhost.
5. Enter next to Multipass Username: tutor@duq.edu and next to Name: Tutorfirst Tutorlast.
6. Click the Login button. You will be directed to the tutor home page.
7. Enter next to Multipass Username: lipeckya@duq.edu and next to Name: Alex Lipecky.  
8. Click the Login button. You will be directed to the administrative home page and see navigation buttons.
9. Proceed to 16CentralizedNavigation.md



