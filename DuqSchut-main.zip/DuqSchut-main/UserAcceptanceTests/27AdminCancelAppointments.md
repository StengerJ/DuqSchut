# User Acceptance test for 27: As an administrator, I want to be able to cancel tutoring appointments.

1. From the home page click the login button under the image.
2. Enter next to Multipass Username: lipeckya@duq.edu and next to Name: Alex Lipecky.
3. On the navigation page, click View Appointments.
4. You should see two appointments listed.
5. Click delete on the second appointment(for student@duq.edu).
6. On the the confirmation page click delete again.
7. You should be navigated back to the list of appointments.