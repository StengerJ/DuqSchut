# User Acceptance Test for 1: As a student, I want to be able to schedule tutoring appointments.

1. From the student appointments page, click "Create New".
2. Select either a Monday or a Wednesday as the date for the appointment.
3. Select the course for the appointment as either COSC 215 or COSC 220 from the dropdown menu next to Course.
4. Type a purpose for the appointment in the text box.
5. Select the tutor for the appointment.
6. Select a start time for the appointment.
7. Select an end time of the appointment.
8. Select the location of the appointment.
9. Click Submit to finalize the appointment.
10. You will be redirected to the student appointments page.
11. You should see the appointment added below User Appointments.
12. Click "Create New".
13. Click Cancel to be redirected to the student appointments page.