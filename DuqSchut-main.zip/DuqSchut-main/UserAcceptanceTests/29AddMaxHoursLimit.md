# User acceptance test for 29: As an administrator, I want to set the maximum number of tutoring hours students can normally have each week

1. Login as administrator, e.g., lipeckya@duq.edu, Alex Lipecky.
2. From the admin navpage, select Student Profiles.
3. In the Max Hours box, enter a number of hours (in increments of 0.5 hours).
4. Click Submit.
5. Screen will update to show that all student hours are rewritten with the new value.