# User Acceptance Test for 46: As a student I want to be able to cancel appointments.

1. Sign in with the email "student@duq.edu" and the name "Studentfirst Studentlast".
2. From the student appointments page, click "Delete" on the future appointment.
3. Click the Delete Button.
4. You will be redirected to the student appointments page with only two appointments remaining.
5. Click the "Delete" on one of the remaining appointments.
6. There should not be a Delete Button to click as the appointment has already occurred.
7. Click the Back Button to be redirected to the student appointments page.