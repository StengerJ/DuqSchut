# User Acceptance Test for 28: As an administrator, I want to set other users as tutors or administrators

1. You should now be on the User Setting page and see a list of users and their roles.
2. The role for Jessica Bowman is currently Student.
3. Click edit to the right of Jessica Bowman.
4. Just above the submit button, there will be a drop down menu where you can select a new role for the user. Select tutor from the dropdown menu and hit submit.
5. You will be redirected to the User Settings page. The role of Jessica Bowman should now be tutor.