# User Acceptance Test for 30: As an administrator, I want to be able to grant individual students additional tutoring hours beyond the normal weekly allotment

1. From the home page, click the login button under the DuqSchut logo.
2. Next to Email: enter lipeckya@duq.edu, and then any password next to Password:
3. Click the log in button, you will be directed to the Admin welcome page
4. Click the button "Student Profiles", you will be directed to a page which displays all of the student profiles associated with the current (or upcoming) term in the system, their name, emails, associated term, and tutoring hours remaining for the week.
5. Click on "Edit" under the actions field, you will be directed to a page that allows you to edit the tutor hours remaining for that student.
6. Either type in the "Tutoring Hours Remaining" text box to change the hours, or press the arros on the text box to add or remove 0.5 hours. 
7. Once you've made the necessary changes, click "Save" and you will be directed back to the student profiles page. 
8. If you do not wish to edit hours while on the edit page, press "Back to List", and you will be directed back to the student profiles page. 