# User acceptance test for 16: As an administrator, I want to access admin features from a centralized location

1. You should now be on the navigation page and see Welcome, Admin! on the top of the page. Underneath, you should see 3 navigation buttons.
3. Click on Semester. You will be directed to a (temporarily) nonexistant page.
4. Click the back button on the browser window.
5. Click on Tutor Profiles. You will be directed to the page where you can approve tutor profiles.
6. Click the back button on the browser window.
7. Click on User Roles. You will be directed to the User settings page.
8. Proceed to 28UserRoles.md