# User Acceptance test for 57: As a tutor, I want to be able to upload a photograph of myself for potential tutees to see when they are scheduling an appointment. 
1. After step #9 of user acceptance test 18TutorProfile.md, click Choose File under "Upload Photo"
3. Browse Documents/GitHub/DuqSchut/wwwroot/DuqSchutLogo
4. With the photo selcted, click open.
5. Continue with step #10 of user acceptance test 18TutorProfile.md

# Note: when you view the profile details you will see the uploaded image. If you choose to not upload a photo, you will see a placeholder.