# User Acceptance test for 32: As a tutor, I want to be able to view my upcoming appointments

1. From the home page click the login button under the image.
2. Enter next to Multipass Username: tutor@duq.edu and next to Name: Tutorfirst TutorLast.
3. On the tutor home page, click View Appointments.
4. You should see two appointments listed.
5. Click details on the first appointment.
6. Proceed to user acceptance test #38