﻿namespace DuqSchut.Tests;

/**
 <summary>
  xUnit test template generated when xUnit project was created.
  This file should be removed once real xUnit tests are written.
 </summary>
*/
public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
